package myMath;

import java.util.StringTokenizer;

public class main {
	public static void main(String[] args) {
		
//		double n=Double.parseDouble("56");
//		System.out.println(n);
//		String s="sttd+tjrjrrjr-djrtrtf+a+fff";
//		StringTokenizer str = new StringTokenizer(s,"+-j");
//		while (str.hasMoreTokens()) {
//			String tmp =  str.nextToken();
//			System.out.print(tmp+" ");
//		}	



		
//		Monom m = new Monom("4");
		
//		Monom b = new Monom("4x^-1");
//		Monom c = new Monom("-x");
//		Monom d = new Monom("-x^2");
//
//
//		System.out.println(m);
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
		Monom a = new Monom("4x^3");
		Polynom p1 = new Polynom("x^5+x^2+6");
		
//		System.out.println(p1.root(-2.3, -1.6, 0.000001));
		
		
		
//		Polynom p  = new Polynom("x+2");
//		Polynom p2 = (Polynom) p1.copy();
//		p1.multiply(p);
//		System.out.println(p1);
		
//		Polynom p3=p1;
//		System.out.println("p1="+p1);
//		System.out.println("p2="+p2);
//		System.out.println("p3="+p3);
//		p1.multiply(a);
//		System.out.println();
//		System.out.println("p1="+p1);
//		System.out.println("p2="+p2);
//		System.out.println("p3="+p3);
		
		
		//System.out.println();
		p1.add(a);
		System.out.println(p1);
		//p1.multiply(a);
		//System.out.println("p1="+p1);
		//System.out.println("p="+p);
		//System.out.println();
		
		//p1.add(p);
		//System.out.println("p1+p= "+p1);
		//System.out.println("p="+p);
		//p.substract(p1);
		//System.out.println("p= "+p);
		
		

	}
}
